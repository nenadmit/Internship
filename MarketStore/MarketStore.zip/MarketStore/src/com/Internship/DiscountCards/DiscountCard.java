package com.Internship.DiscountCards;

public interface DiscountCard {

    public double getPurchaseValue();

    public double getDiscountRate();

}
